import React, { Component } from 'react'

export default class GioHang extends Component {
    
    renderGioHang = () => {
        let mangGioHang = this.state.GioHang;
        return mangGioHang.map ((item, index) => {
            
        })
    }
    
    render() {
        return (
            <div>
                <table className="table">
                    <thead>
                        <tr>
                            <th>Hình ảnh</th>
                            <th>Tên sản phẩm</th>
                            <th>Đơn giá</th>
                            <th>Số lượng</th>
                            <th>Thành tiền</th>
                            <th>Thao tác</th>
                        </tr>
                    </thead>
                    <tbody>

                    </tbody>
                </table>
            </div>
        )
    }
}
